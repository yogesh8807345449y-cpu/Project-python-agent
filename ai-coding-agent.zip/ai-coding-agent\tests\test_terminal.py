"""Unit tests for the safe Terminal execution tool."""

import os
import sys
import tempfile
from pathlib import Path
import pytest

from agent.terminal import Terminal


def test_terminal_basic_command():
    with tempfile.TemporaryDirectory() as tmpdir:
        term = Terminal(root_dir=tmpdir)
        res = term.run("python -c \"print('hello from terminal')\"")
        assert res.exit_code == 0
        assert "hello from terminal" in res.stdout
        assert res.duration >= 0.0
        assert not res.timed_out


def test_terminal_cwd_isolation():
    with tempfile.TemporaryDirectory() as tmpdir:
        term = Terminal(root_dir=tmpdir)
        # Attempt to run command outside root_dir
        outside_dir = Path(tmpdir).parent
        res = term.run("python -c \"print('forbidden')\"", cwd=outside_dir)
        assert res.exit_code == -1
        assert "Security Error" in res.stderr


def test_terminal_dangerous_command_blocked():
    with tempfile.TemporaryDirectory() as tmpdir:
        term = Terminal(root_dir=tmpdir)
        res = term.run("rm -rf /")
        assert res.exit_code == -1
        assert "dangerous pattern" in res.stderr


def test_terminal_timeout():
    with tempfile.TemporaryDirectory() as tmpdir:
        term = Terminal(root_dir=tmpdir, timeout=1)
        res = term.run("python -c \"import time; time.sleep(3)\"", timeout=1)
        assert res.timed_out is True
        assert res.exit_code == -1
        assert "timed out" in res.stderr.lower()
