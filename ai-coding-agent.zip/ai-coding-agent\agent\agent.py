"""Main CodingAgent orchestrator implementing the end-to-end 16-step software engineering workflow."""

import json
import logging
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from config import Config, default_config
from models.schemas import (
    AgentResult,
    DebugIteration,
    FileChange,
    Plan,
    PlanStep,
    RepoInfo,
    StepAction,
    TestResult,
)
from agent.analyzer import CodeAnalyzer
from agent.approval import ApprovalHandler
from agent.debugger import Debugger
from agent.editor import FileEditor
from agent.llm import LLMClient, get_llm_client
from agent.planner import Planner
from agent.repository import RepositoryManager
from agent.search import RepositorySearch
from agent.terminal import Terminal
from agent.tester import TestRunner

logger = logging.getLogger(__name__)


class CodingAgent:
    """Lightweight autonomous software-engineering assistant."""

    def __init__(
        self,
        config: Optional[Config] = None,
        llm_client: Optional[LLMClient] = None,
        status_callback: Optional[Callable[[str], None]] = None,
    ):
        self.config = config or default_config
        self.llm = llm_client or get_llm_client(self.config)
        self.status_callback = status_callback

        self.repo_manager = RepositoryManager(self.config)
        self.repo_info: Optional[RepoInfo] = None
        self.terminal: Optional[Terminal] = None
        self.searcher: Optional[RepositorySearch] = None
        self.editor: Optional[FileEditor] = None
        self.analyzer: Optional[CodeAnalyzer] = None
        self.planner: Optional[Planner] = None
        self.approval: Optional[ApprovalHandler] = None
        self.tester: Optional[TestRunner] = None
        self.debugger: Optional[Debugger] = None

    def _notify(self, message: str) -> None:
        """Send status update to observer or logger."""
        if self.status_callback:
            self.status_callback(message)
        logger.info(message)

    def load_repository(self, target: str) -> RepoInfo:
        """Step 1 & 2: Clone or open the repository."""
        self._notify(f"Opening repository: {target}")
        if target.startswith("http://") or target.startswith("https://") or target.startswith("git@"):
            self.repo_info = self.repo_manager.clone_repo(target)
        else:
            self.repo_info = self.repo_manager.open_repo(target)

        repo_path = Path(self.repo_info.path)
        self.terminal = Terminal(root_dir=repo_path, timeout=self.config.command_timeout)
        self.searcher = RepositorySearch(repo_path=repo_path, config=self.config)
        self.editor = FileEditor(repo_path=repo_path)
        self.analyzer = CodeAnalyzer(self.repo_info, self.searcher, self.editor)
        self.planner = Planner(self.llm)
        self.approval = ApprovalHandler(auto_approve=self.config.auto_approve)
        self.tester = TestRunner(repo_path=repo_path, terminal=self.terminal)
        self.debugger = Debugger(
            llm=self.llm,
            editor=self.editor,
            tester=self.tester,
            max_iterations=self.config.max_debug_iterations,
        )

        # Step 3 & 4: Structure scanned and important files identified
        self._notify(
            f"Repository loaded: '{self.repo_info.name}' | Languages: {', '.join(self.repo_info.languages) or 'Unknown'} "
            f"| Test Runners: {', '.join(self.repo_info.test_runners) or 'None detected'}"
        )
        return self.repo_info

    def run(self, repo_target: str, task: str) -> AgentResult:
        """Execute the full 16-step workflow for a coding task on a repository."""
        # 1-4. Open & Scan Repository
        if not self.repo_info or self.repo_info.path != str(Path(repo_target).resolve()):
            self.load_repository(repo_target)

        assert self.repo_info is not None
        assert self.analyzer is not None
        assert self.planner is not None
        assert self.approval is not None
        assert self.editor is not None
        assert self.tester is not None
        assert self.debugger is not None

        # 5-7. Search repository & analyze task and relevant code
        self._notify(f"Analyzing task and indexing relevant codebase symbols: '{task}'")
        context = self.analyzer.analyze_task_context(task)

        # 8. Create implementation plan
        self._notify("Synthesizing structured implementation plan...")
        plan = self.planner.create_plan(task, context)

        # 9. Request approval before making major changes
        self._notify("Requesting user approval...")
        approved = self.approval.request_plan_approval(plan)
        if not approved:
            self._notify("Plan execution was rejected by user. Aborting.")
            return AgentResult(
                success=False,
                task=task,
                repo_info=self.repo_info,
                plan=plan,
                files_modified=[],
                diff_summary="",
                tests_executed=[],
                debug_iterations=[],
                final_summary="Plan rejected by user. No files were modified.",
            )

        # 10. Modify required files according to plan
        self._notify("Applying proposed code modifications...")
        files_modified = self._execute_plan_modifications(plan, context)

        # 11. Run appropriate commands / tests
        test_command = plan.verification_commands[0] if plan.verification_commands else None
        if test_command:
            parts = test_command.strip().split()
            if parts and parts[0] == "pytest":
                test_command = "python -m " + test_command.strip()

        self._notify(f"Running test verification suite: '{test_command or 'default runner'}'")
        initial_test_result = self.tester.run_tests(command=test_command, repo_info=self.repo_info)
        tests_executed = [initial_test_result]

        # 12-15. Analyze test results and run iterative debug loop if failed
        debug_iterations: List[DebugIteration] = []
        overall_success = initial_test_result.is_success

        if not overall_success:
            self._notify(
                f"Tests failed (exit code {initial_test_result.exit_code}). "
                f"Entering automated debugging and repair loop..."
            )
            debug_success, debug_iterations = self.debugger.debug_and_fix(
                test_result=initial_test_result,
                test_command=initial_test_result.command,
                relevant_files=list(set(files_modified + context.get("relevant_files", []))),
            )
            overall_success = debug_success
            if debug_iterations and debug_iterations[-1].test_result:
                tests_executed.append(debug_iterations[-1].test_result)
        else:
            self._notify("All tests passed on initial execution!")

        # 16. Display final summary
        diff_summary = self.editor.get_diff()
        all_modified_files = sorted(list(self.editor.modified_files))

        status_str = "SUCCESS" if overall_success else "FAILED / PARTIAL"
        final_summary = (
            f"Task Execution Completed: [{status_str}]\n"
            f"- Modified Files ({len(all_modified_files)}): {', '.join(all_modified_files) or 'None'}\n"
            f"- Tests Executed: {len(tests_executed)} suite run(s)\n"
            f"- Debug Iterations: {len(debug_iterations)}\n"
            f"- Status: {'All verification tests passing.' if overall_success else 'Some tests still failing.'}"
        )

        self._notify(final_summary)

        return AgentResult(
            success=overall_success,
            task=task,
            repo_info=self.repo_info,
            plan=plan,
            files_modified=all_modified_files,
            diff_summary=diff_summary,
            tests_executed=tests_executed,
            debug_iterations=debug_iterations,
            final_summary=final_summary,
        )

    def _execute_plan_modifications(self, plan: Plan, context: Dict[str, Any]) -> List[str]:
        """Apply the steps in the plan to repository files."""
        assert self.editor is not None
        modified: List[str] = []

        for step in plan.steps:
            if step.action == StepAction.DELETE and step.target_file:
                self.editor.delete_file(step.target_file)
                modified.append(step.target_file)
            elif step.action == StepAction.COMMAND and step.details and self.terminal:
                self.terminal.run(step.details)
            elif step.action in (StepAction.MODIFY, StepAction.CREATE) and step.target_file:
                self._apply_file_update(step, context)
                modified.append(step.target_file)

        return modified

    def _apply_file_update(self, step: PlanStep, context: Dict[str, Any]) -> None:
        """Generate and apply code update for a specific plan step."""
        assert self.editor is not None
        assert step.target_file is not None

        existing_content = ""
        try:
            existing_content = self.editor.read_file(step.target_file)
        except Exception:
            existing_content = ""

        # Query LLM to formulate exact edit or file content
        system_prompt = (
            "You are an expert programmer modifying code according to an approved plan. "
            "Output the updated complete file content or targeted edits. "
            "Output ONLY valid code or JSON with 'new_content'."
        )

        prompt = f"""
TASK: {step.description}
TARGET FILE: {step.target_file}
DETAILS: {step.details or 'Implement necessary updates.'}

EXISTING FILE CONTENT:
```
{existing_content}
```

INSTRUCTIONS:
Return a JSON object containing:
{{
  "new_content": "complete updated content of the file"
}}
"""
        response = self.llm.generate(prompt=prompt, system=system_prompt, temperature=0.1)

        # Extract new_content from JSON or use cleaned code block
        new_content = None
        clean_json = response.strip()
        if "```" in clean_json:
            matches = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", clean_json, re.DOTALL)
            if matches:
                clean_json = matches[0]

        try:
            parsed = json.loads(clean_json)
            new_content = parsed.get("new_content")
        except Exception:
            # Fallback: check if entire response is a fenced code block
            code_blocks = re.findall(r"```(?:\w+)?\n(.*?)\n```", response, re.DOTALL)
            if code_blocks:
                new_content = code_blocks[0]
            elif existing_content and step.details:
                # If LLM didn't return JSON or code block, fallback to applying details if meaningful
                new_content = existing_content

        if new_content is not None and new_content != existing_content:
            self.editor.write_file(step.target_file, new_content)
