"""Implementation planner for generating structured, actionable development plans."""

import json
import logging
import re
from typing import Any, Dict, List, Optional

from models.schemas import Plan, PlanStep, StepAction
from agent.llm import LLMClient

logger = logging.getLogger(__name__)


class Planner:
    """Uses LLM to formulate step-by-step implementation plans from task specifications and codebase context."""

    def __init__(self, llm_client: LLMClient):
        self.llm = llm_client

    def create_plan(self, task: str, context: Dict[str, Any]) -> Plan:
        """Formulate a structured implementation plan."""
        system_prompt = (
            "You are an expert software engineer and technical lead. "
            "Your job is to analyze user tasks and codebase context to produce a structured, accurate, "
            "and minimal implementation plan that solves the problem without breaking existing code."
        )

        prompt = f"""
USER TASK:
{task}

REPOSITORY CONTEXT:
Overview: {json.dumps(context.get('repo_overview', {}), indent=2)}
Relevant Files Found: {json.dumps(context.get('relevant_files', []), indent=2)}
Identified Symbols: {json.dumps(context.get('symbols', []), indent=2)}

CODE SNIPPETS:
{json.dumps(context.get('file_snippets', {}), indent=2)}

INSTRUCTIONS:
1. Formulate a step-by-step plan to accomplish the user task.
2. Only modify or create files that are strictly necessary.
3. Specify verification commands (e.g. test runner commands) to test your changes.
4. Output your plan strictly as a JSON object adhering to this schema:
{{
  "summary": "Brief 1-sentence summary of the plan",
  "rationale": "Why this approach is taken and root cause explanation",
  "steps": [
    {{
      "step_number": 1,
      "action": "modify",  // "modify", "create", "delete", or "command"
      "target_file": "path/to/file.ext",
      "description": "Short step summary",
      "details": "Specific code logic or edits to apply"
    }}
  ],
  "verification_commands": ["pytest"],
  "potential_risks": ["Potential edge case or side effect"]
}}
"""

        raw_response = self.llm.generate(prompt=prompt, system=system_prompt, temperature=0.1)
        return self._parse_plan_response(task, raw_response, context)

    def _parse_plan_response(self, task: str, response: str, context: Dict[str, Any]) -> Plan:
        """Parse LLM response into a structured Plan object with robust JSON extraction."""
        # Clean response of markdown code blocks
        clean_json = response.strip()
        if "```" in clean_json:
            json_matches = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", clean_json, re.DOTALL)
            if json_matches:
                clean_json = json_matches[0]
            else:
                clean_json = re.sub(r"^```(?:json)?\s*", "", clean_json)
                clean_json = re.sub(r"\s*```$", "", clean_json)

        try:
            data = json.loads(clean_json)
            steps = []
            for s in data.get("steps", []):
                action_str = s.get("action", "modify").lower()
                try:
                    action_enum = StepAction(action_str)
                except ValueError:
                    action_enum = StepAction.MODIFY

                steps.append(
                    PlanStep(
                        step_number=s.get("step_number", len(steps) + 1),
                        action=action_enum,
                        target_file=s.get("target_file"),
                        description=s.get("description", ""),
                        details=s.get("details"),
                    )
                )

            # Determine verification commands
            verification = data.get("verification_commands", [])
            if not verification:
                # Fallback to detected test runners from repo
                runners = context.get("repo_overview", {}).get("test_runners", [])
                if runners:
                    runner_cmd = runners[0]
                    if runner_cmd.lower() == "pytest":
                        runner_cmd = "python -m pytest"
                    verification = [runner_cmd]
                else:
                    verification = ["python -m pytest"]

            return Plan(
                task=task,
                summary=data.get("summary", "Execute task implementation."),
                rationale=data.get("rationale", "Apply targeted source code modifications."),
                steps=steps,
                verification_commands=verification,
                potential_risks=data.get("potential_risks", []),
            )
        except Exception as e:
            logger.warning(f"Failed to parse structured JSON plan ({e}). Generating fallback plan from text.")
            return self._build_fallback_plan(task, response, context)

    def _build_fallback_plan(self, task: str, response_text: str, context: Dict[str, Any]) -> Plan:
        """Construct fallback plan when JSON parsing fails."""
        relevant_files = context.get("relevant_files", [])
        primary_file = relevant_files[0] if relevant_files else "main.py"
        test_runners = context.get("repo_overview", {}).get("test_runners", ["python -m pytest"])
        verification = ["python -m pytest" if r.lower() == "pytest" else r for r in test_runners]

        step = PlanStep(
            step_number=1,
            action=StepAction.MODIFY,
            target_file=primary_file,
            description="Implement required logic updates.",
            details=response_text[:300],
        )

        return Plan(
            task=task,
            summary="Implement modifications according to task description.",
            rationale="Derived from task description and repository context.",
            steps=[step],
            verification_commands=verification,
            potential_risks=["Verify that all edge cases and tests pass."],
        )
