"""Code and task analyzer for generating high-signal, targeted context for the LLM."""

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from models.schemas import RepoInfo, SearchMatch, SymbolInfo
from agent.editor import FileEditor
from agent.search import RepositorySearch


class CodeAnalyzer:
    """Extracts keywords from user tasks, locates relevant code, and builds context for planning and debugging."""

    # Words to ignore when extracting keywords from task description
    STOP_WORDS = {
        "a", "an", "the", "in", "on", "at", "to", "for", "with", "by", "about",
        "and", "or", "of", "is", "are", "was", "were", "be", "been", "being",
        "it", "this", "that", "these", "those", "we", "you", "i", "they",
        "fix", "bug", "issue", "error", "problem", "update", "change", "modify",
        "implement", "create", "add", "make", "please", "help", "do", "does",
    }

    # Semantic synonyms for common programming domains
    DOMAIN_SYNONYMS = {
        "login": ["auth", "authenticate", "password", "token", "session", "user", "credential"],
        "auth": ["login", "authenticate", "token", "jwt", "session", "permission"],
        "cart": ["checkout", "order", "item", "total", "price", "basket"],
        "database": ["db", "query", "sql", "model", "schema", "table", "entity"],
        "api": ["route", "endpoint", "controller", "handler", "request", "response"],
        "test": ["spec", "assert", "mock", "fixture"],
    }

    def __init__(self, repo_info: RepoInfo, searcher: RepositorySearch, editor: FileEditor):
        self.repo_info = repo_info
        self.searcher = searcher
        self.editor = editor

    def extract_keywords(self, task: str) -> List[str]:
        """Extract meaningful keywords and domain synonyms from user task description."""
        # Find explicit filenames or symbols mentioned (e.g. cart.py, calculate_total)
        words = re.findall(r"[a-zA-Z0-9_\-\.]+", task)
        keywords: Set[str] = set()

        for w in words:
            clean = w.strip(".,;:?!'\"()")
            clean_lower = clean.lower()
            if not clean_lower or clean_lower in self.STOP_WORDS or len(clean) < 3:
                continue
            keywords.add(clean)

            # Add domain synonyms if applicable
            if clean_lower in self.DOMAIN_SYNONYMS:
                keywords.update(self.DOMAIN_SYNONYMS[clean_lower])

        return sorted(list(keywords), key=len, reverse=True)

    def analyze_task_context(self, task: str, max_files: int = 5, max_lines_per_snippet: int = 60) -> Dict[str, Any]:
        """Build focused repository context for the given user task."""
        keywords = self.extract_keywords(task)
        matched_files: Set[str] = set()
        matched_symbols: List[SymbolInfo] = []
        file_snippets: Dict[str, str] = {}

        # 1. Search for explicit file names mentioned in task
        for kw in keywords:
            if "." in kw:
                found = self.searcher.search_file(f"*{kw}*")
                matched_files.update(found[:3])

        # 2. Search for symbols
        for kw in keywords:
            if "_" in kw or kw.isidentifier():
                symbols = self.searcher.search_symbol(kw)
                if symbols:
                    matched_symbols.extend(symbols[:3])
                    for s in symbols[:3]:
                        matched_files.add(s.file_path)

        # 3. Content search for keywords
        for kw in keywords[:5]:
            search_res = self.searcher.search(kw, max_results=10)
            for m in search_res.matches:
                matched_files.add(m.file_path)

        # 4. Extract targeted snippets from matched files
        prioritized_files = sorted(list(matched_files))[:max_files]
        for fpath in prioritized_files:
            try:
                full_text = self.editor.read_file(fpath)
                lines = full_text.splitlines()
                if len(lines) <= max_lines_per_snippet:
                    file_snippets[fpath] = full_text
                else:
                    # Give initial section plus lines matching keywords
                    snippet_lines = lines[:25]
                    snippet_lines.append("\n... [truncated] ...\n")
                    file_snippets[fpath] = "\n".join(snippet_lines)
            except Exception:
                continue

        return {
            "keywords": keywords,
            "relevant_files": prioritized_files,
            "symbols": [s.model_dump() for s in matched_symbols],
            "file_snippets": file_snippets,
            "repo_overview": {
                "name": self.repo_info.name,
                "languages": self.repo_info.languages,
                "package_managers": self.repo_info.package_managers,
                "build_systems": self.repo_info.build_systems,
                "test_runners": self.repo_info.test_runners,
                "git_branch": self.repo_info.git_branch,
            },
        }
