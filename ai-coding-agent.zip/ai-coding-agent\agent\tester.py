"""Test runner and test result parser across multiple languages and frameworks."""

import re
from pathlib import Path
from typing import List, Optional, Union

from models.schemas import CommandResult, RepoInfo, TestResult
from agent.terminal import Terminal


class TestRunner:
    """Dispatches test suites and parses standard test outputs."""
    __test__ = False

    def __init__(self, repo_path: Union[str, Path], terminal: Terminal):
        self.repo_path = Path(repo_path).resolve()
        self.terminal = terminal

    def run_tests(
        self,
        command: Optional[str] = None,
        repo_info: Optional[RepoInfo] = None,
        timeout: int = 120,
    ) -> TestResult:
        """Run tests and parse outcomes."""
        test_cmd = command
        if not test_cmd:
            test_cmd = self.determine_default_test_command(repo_info)

        cmd_res = self.terminal.run(test_cmd, timeout=timeout)
        return self.parse_test_output(test_cmd, cmd_res)

    def determine_default_test_command(self, repo_info: Optional[RepoInfo]) -> str:
        """Derive the most suitable test command from repository metadata."""
        if repo_info and repo_info.test_runners:
            first_runner = repo_info.test_runners[0].lower()
            if "pytest" in first_runner:
                return "python -m pytest"
            elif "npm test" in first_runner:
                return "npm test"
            elif "cargo test" in first_runner:
                return "cargo test"
            elif "go test" in first_runner:
                return "go test ./..."
            elif "mvn test" in first_runner:
                return "mvn test"
            elif "gradle test" in first_runner:
                return "gradle test"
            elif "ctest" in first_runner:
                return "ctest"

        # Check files on disk
        if (self.repo_path / "Cargo.toml").exists():
            return "cargo test"
        if (self.repo_path / "package.json").exists():
            return "npm test"
        if (self.repo_path / "go.mod").exists():
            return "go test ./..."
        if (self.repo_path / "pom.xml").exists():
            return "mvn test"

        # Default fallback for Python
        return "python -m pytest"

    def parse_test_output(self, command: str, cmd_res: CommandResult) -> TestResult:
        """Extract structured statistics and failure information from test runner outputs."""
        output = (cmd_res.stdout or "") + "\n" + (cmd_res.stderr or "")
        exit_code = cmd_res.exit_code

        runner_name = command.split()[0]
        passed = 0
        failed = 0
        skipped = 0
        failed_tests: List[str] = []
        error_summary_lines: List[str] = []

        # 1. Pytest Parsing
        # Pattern: "= 1 failed, 3 passed in 0.12s ="
        pytest_summary = re.search(r"(=+.*(?:passed|failed|error|skipped).*=+)", output)
        if pytest_summary:
            summary_line = pytest_summary.group(1)
            passed_match = re.search(r"(\d+)\s+passed", summary_line)
            failed_match = re.search(r"(\d+)\s+failed", summary_line)
            skipped_match = re.search(r"(\d+)\s+skipped", summary_line)
            error_match = re.search(r"(\d+)\s+error", summary_line)

            if passed_match:
                passed = int(passed_match.group(1))
            if failed_match:
                failed = int(failed_match.group(1))
            if error_match:
                failed += int(error_match.group(1))
            if skipped_match:
                skipped = int(skipped_match.group(1))

        # Extract failed test identifiers in pytest (FAILED test_foo.py::test_bar - ...)
        for line in output.splitlines():
            if line.startswith("FAILED "):
                failed_identifier = line.removeprefix("FAILED ").split()[0]
                failed_tests.append(failed_identifier)
            elif "=== FAILURES ===" in line or "AssertionError" in line:
                error_summary_lines.append(line)

        # 2. Cargo test parsing (test result: FAILED. 1 passed; 1 failed; 0 ignored)
        cargo_summary = re.search(r"test result:\s*(ok|FAILED)\.\s*(\d+)\s*passed;\s*(\d+)\s*failed;\s*(\d+)\s*ignored", output)
        if cargo_summary:
            passed = int(cargo_summary.group(2))
            failed = int(cargo_summary.group(3))
            skipped = int(cargo_summary.group(4))

        # 3. Go test parsing (FAIL: TestFoo)
        go_failures = re.findall(r"--- FAIL:\s*(\w+)", output)
        if go_failures:
            failed_tests.extend(go_failures)
            failed = max(failed, len(go_failures))

        # 4. Jest / npm test parsing (Tests: 1 failed, 4 passed, 5 total)
        jest_match = re.search(r"Tests:\s*(?:(\d+)\s*failed,)?\s*(?:(\d+)\s*passed,)?\s*(\d+)\s*total", output)
        if jest_match:
            if jest_match.group(1):
                failed = int(jest_match.group(1))
            if jest_match.group(2):
                passed = int(jest_match.group(2))

        # If exit code was non-zero and no failed count was detected, count as at least 1 failure
        if exit_code != 0 and failed == 0:
            failed = 1
            if not error_summary_lines:
                error_summary_lines.append(output[-500:] if len(output) > 500 else output)

        error_summary = "\n".join(error_summary_lines) if error_summary_lines else (output[-1000:] if failed > 0 else "")

        return TestResult(
            runner=runner_name,
            command=command,
            exit_code=exit_code,
            passed=passed,
            failed=failed,
            skipped=skipped,
            raw_output=output,
            failed_tests=failed_tests,
            error_summary=error_summary,
        )
