"""Unit tests for TestRunner output parsing."""

import tempfile
from pathlib import Path
import pytest

from agent.terminal import Terminal
from agent.tester import TestRunner
from models.schemas import CommandResult


def test_tester_pytest_parsing():
    with tempfile.TemporaryDirectory() as tmpdir:
        term = Terminal(root_dir=tmpdir)
        tester = TestRunner(repo_path=tmpdir, terminal=term)

        # Mock pytest output
        sample_output = """
============================= test session starts =============================
collected 3 items

tests/test_calc.py .F.                                                   [100%]

================================== FAILURES ===================================
_______________________________ test_calculate ________________________________
    def test_calculate():
>       assert calculate_total([10]) == 100
E       assert 10 == 100

FAILED tests/test_calc.py::test_calculate - assert 10 == 100
========================= 1 failed, 2 passed in 0.12s =========================
"""
        cmd_res = CommandResult(
            command="pytest",
            stdout=sample_output,
            stderr="",
            exit_code=1,
            duration=0.5,
        )

        tr = tester.parse_test_output("pytest", cmd_res)
        assert tr.passed == 2
        assert tr.failed == 1
        assert not tr.is_success
        assert len(tr.failed_tests) == 1
        assert "tests/test_calc.py::test_calculate" in tr.failed_tests[0]


def test_tester_cargo_parsing():
    with tempfile.TemporaryDirectory() as tmpdir:
        term = Terminal(root_dir=tmpdir)
        tester = TestRunner(repo_path=tmpdir, terminal=term)

        sample_output = """
running 3 tests
test tests::test_add ... ok
test tests::test_sub ... FAILED
test tests::test_mult ... ok

failures:
---- tests::test_sub stdout ----
thread 'tests::test_sub' panicked at 'assertion failed: `(left == right)`'

test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out
"""
        cmd_res = CommandResult(
            command="cargo test",
            stdout=sample_output,
            stderr="",
            exit_code=101,
            duration=1.2,
        )

        tr = tester.parse_test_output("cargo test", cmd_res)
        assert tr.passed == 2
        assert tr.failed == 1
        assert not tr.is_success
