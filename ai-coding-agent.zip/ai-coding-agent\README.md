# Autonomous AI Coding Agent 🤖

A modular, lightweight autonomous software engineering assistant in Python 3.11+. The agent inspects repositories across multiple programming languages, understands project structures, searches code symbols, generates structured implementation plans, requests user approval before making modifications, executes commands safely, runs test suites, and performs automated iterative debugging when tests fail.

---

## Architecture & Workflow

```mermaid
flowchart TD
    A["1. Repository Intake<br/>(Git clone or local path)"] --> B["2. Codebase Scanner<br/>(Languages, Package Managers, Tests)"]
    B --> C["3. Task Intake & Keyword Analysis<br/>(Domain synonyms, symbol lookup)"]
    C --> D["4. Search & Context Builder<br/>(Ripgrep / Python fallback)"]
    D --> E["5. LLM Planner<br/>(Structured steps, risks, tests)"]
    E --> F{"6. User Approval<br/>(Approve, Diff, Reject)"}
    F -- "Approved" --> G["7. File Editor<br/>(Sandboxed file modifications)"]
    F -- "Rejected" --> Z["Abort / Exit"]
    G --> H["8. Test Runner<br/>(Pytest, Cargo, Jest, Go, etc.)"]
    H --> I{"Tests Passed?"}
    I -- "Yes" --> J["9. Summary & Diff Report"]
    I -- "No" --> K["10. Automated Debugger<br/>(Analyze failure trace & diagnose)"]
    K --> L["11. Targeted Patch & Re-test"]
    L --> I
```

### Complete 16-Step Lifecycle
1. User supplies a GitHub repository URL or local repository path.
2. Agent clones or opens the repository.
3. Agent scans repository structure.
4. Agent identifies source files, configurations, documentation, and tests.
5. Agent indexes and searches repository contents.
6. User provides a coding task.
7. Agent analyzes the task and extracts relevant symbols & keywords.
8. Agent creates a clear, structured implementation plan.
9. Agent asks the user for approval before modifying code.
10. After approval, agent modifies the required files.
11. Agent executes appropriate commands and test suites.
12. Agent analyzes test results, exit codes, and error traces.
13. Agent diagnoses root causes and formulates targeted fixes.
14. Agent re-runs tests.
15. Agent repeats debugging until tests succeed or retry limit is reached.
16. Agent outputs files changed, tests executed, diffs, and final results.

---

## Supported Languages & Toolchains

The agent automatically detects and supports projects in:
- **Python**: `pip`, `poetry`, `pyproject.toml`, `setup.py`, `pytest`, `unittest`
- **JavaScript & TypeScript**: `npm`, `package.json`, `tsconfig.json`, `jest`, `vitest`
- **Rust**: `cargo`, `Cargo.toml`, `cargo test`
- **Go**: `go modules`, `go.mod`, `go test`
- **Java**: `maven`, `gradle`, `pom.xml`, `build.gradle`, `mvn test`, `gradle test`
- **C & C++**: `CMakeLists.txt`, `Makefile`, `ctest`, `make test`

---

## Installation

### Prerequisites
- Python 3.11+
- Git

### Install Dependencies
```bash
pip install -r requirements.txt
```

---

## Configuration

Copy `.env.example` to `.env` and set your preferred LLM provider:

```env
# LLM Provider: 'openai', 'mock' (offline test mode)
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o-mini
LLM_API_KEY=your_openai_api_key_here

# Optional: custom base URL (e.g. Ollama, vLLM, DeepSeek, OpenRouter)
LLM_BASE_URL=

# Execution Limits
MAX_DEBUG_ITERATIONS=3
COMMAND_TIMEOUT=120
AUTO_APPROVE=false
```

---

## Usage

### 1. Inspect and Work on a Local Repository
```bash
python main.py --repo ./my-project --task "Fix the authentication token expiry bug"
```

### 2. Clone and Work on a Remote GitHub Repository
```bash
python main.py --repo https://github.com/user/sample-repo.git --task "Add unit tests for user registration"
```

### 3. Non-Interactive / CI Auto-Approve Mode
```bash
python main.py --repo ./my-project --task "Fix calculation error" --auto-approve
```

### 4. Interactive Mode
```bash
python main.py --interactive
```

---

## Running Test Suite

Run the full automated test suite to verify repository inspection, searching, sandboxing, editing, testing, debugging, and end-to-end bug fixing:

```bash
pytest tests -v
```
