"""Iterative debugger for analyzing test failures, formulating fixes, and re-verifying."""

import json
import logging
import re
from typing import Dict, List, Optional, Tuple

from models.schemas import DebugIteration, TestResult
from agent.editor import FileEditor
from agent.llm import LLMClient
from agent.tester import TestRunner

logger = logging.getLogger(__name__)


class Debugger:
    """Diagnoses test failures and applies targeted code repairs iteratively until tests succeed."""

    def __init__(
        self,
        llm: LLMClient,
        editor: FileEditor,
        tester: TestRunner,
        max_iterations: int = 3,
    ):
        self.llm = llm
        self.editor = editor
        self.tester = tester
        self.max_iterations = max_iterations

    def debug_and_fix(
        self,
        test_result: TestResult,
        test_command: str,
        relevant_files: List[str],
    ) -> Tuple[bool, List[DebugIteration]]:
        """Run iterative repair loop on failing tests.

        Returns:
            Tuple of (overall_success: bool, iterations: List[DebugIteration])
        """
        current_result = test_result
        iterations: List[DebugIteration] = []

        if current_result.is_success:
            return True, iterations

        for i in range(1, self.max_iterations + 1):
            logger.info(f"Starting debug iteration {i}/{self.max_iterations}...")

            # 1. Gather code context for failing files
            file_contexts: Dict[str, str] = {}
            for fpath in relevant_files:
                try:
                    file_contexts[fpath] = self.editor.read_file(fpath)
                except Exception:
                    continue

            # 2. Formulate diagnosis & fix from LLM
            diagnosis, edits = self._diagnose_and_generate_fix(current_result, file_contexts)

            # 3. Apply edits
            files_modified = []
            for edit in edits:
                fpath = edit.get("file_path")
                if not fpath:
                    continue

                try:
                    if "replace_block" in edit and "search_block" in edit:
                        self.editor.replace_content(
                            file_path=fpath,
                            target_content=edit["search_block"],
                            replacement_content=edit["replace_block"],
                        )
                        files_modified.append(fpath)
                    elif "full_content" in edit:
                        self.editor.write_file(fpath, edit["full_content"])
                        files_modified.append(fpath)
                except Exception as e:
                    logger.warning(f"Could not apply edit to {fpath}: {e}")

            # 4. Rerun tests
            new_test_result = self.tester.run_tests(command=test_command)
            iteration_success = new_test_result.is_success

            iteration_record = DebugIteration(
                iteration=i,
                failing_tests=current_result.failed_tests,
                error_summary=current_result.error_summary[:400],
                diagnosis=diagnosis,
                files_modified=files_modified,
                test_result=new_test_result,
                success=iteration_success,
            )
            iterations.append(iteration_record)

            if iteration_success:
                logger.info(f"Debug iteration {i} succeeded! All tests passing.")
                return True, iterations

            # Update current result for next iteration
            current_result = new_test_result

        return False, iterations

    def _diagnose_and_generate_fix(
        self,
        test_result: TestResult,
        file_contexts: Dict[str, str],
    ) -> Tuple[str, List[Dict[str, str]]]:
        """Prompt the LLM to inspect failures and provide exact edits."""
        system_prompt = (
            "You are an expert software debugger. Analyze the test failure output, identify the root cause, "
            "and output the precise code modification required to fix the failure."
        )

        prompt = f"""
FAILING TEST OUTPUT:
{test_result.raw_output[-1500:]}

FAILED TEST IDENTIFIERS:
{json.dumps(test_result.failed_tests, indent=2)}

CURRENT SOURCE CODE:
{json.dumps(file_contexts, indent=2)}

INSTRUCTIONS:
1. Diagnose why the test failed.
2. Provide exact code replacements to resolve the failure.
3. Respond strictly with a JSON object:
{{
  "diagnosis": "Explanation of root cause bug",
  "edits": [
    {{
      "file_path": "path/to/file.py",
      "search_block": "exact lines of code to replace",
      "replace_block": "new corrected lines of code"
    }}
  ]
}}
"""

        response = self.llm.generate(prompt=prompt, system=system_prompt, temperature=0.1)

        # Parse JSON
        clean_json = response.strip()
        if "```" in clean_json:
            json_matches = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", clean_json, re.DOTALL)
            if json_matches:
                clean_json = json_matches[0]
            else:
                clean_json = re.sub(r"^```(?:json)?\s*", "", clean_json)
                clean_json = re.sub(r"\s*```$", "", clean_json)

        try:
            data = json.loads(clean_json)
            diagnosis = data.get("diagnosis", "Applied automated fix based on error trace.")
            edits = data.get("edits", [])
            return diagnosis, edits
        except Exception as e:
            logger.warning(f"Failed to parse debug JSON ({e}). Attempting heuristic extraction.")
            return "Heuristic diagnosis applied.", []
