"""Unit tests for FileEditor operations, diffing, and rollback."""

import tempfile
from pathlib import Path
import pytest

from agent.editor import FileEditor


def test_editor_crud_and_diff():
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        editor = FileEditor(repo_path=root)

        # 1. Write new file
        change = editor.write_file("module.py", "def add(a, b):\n    return a - b\n")
        assert change.is_new_file is True
        assert "module.py" in editor.modified_files
        assert editor.read_file("module.py") == "def add(a, b):\n    return a - b\n"

        # 2. Replace content
        editor.replace_content("module.py", "return a - b", "return a + b")
        assert "return a + b" in editor.read_file("module.py")

        # 3. Check diff
        diff = editor.get_diff("module.py")
        assert "+    return a + b" in diff

        # 4. View lines
        lines = editor.view_lines("module.py", 1, 2)
        assert "def add" in lines

        # 5. Rollback
        reverted = editor.rollback()
        assert "module.py" in reverted
        assert not (root / "module.py").exists()


def test_editor_security_traversal_blocked():
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        editor = FileEditor(repo_path=root)

        with pytest.raises(PermissionError):
            editor.write_file("../forbidden.txt", "evil")
