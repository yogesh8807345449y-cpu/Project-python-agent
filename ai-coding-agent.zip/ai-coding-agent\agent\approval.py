"""User approval handler for reviewing plans, diffs, and confirming major modifications."""

import sys
from typing import Callable, Optional

from models.schemas import Plan


class ApprovalHandler:
    """Handles user approval before executing plans or making major changes."""

    def __init__(
        self,
        auto_approve: bool = False,
        prompt_callback: Optional[Callable[[str], str]] = None,
    ):
        self.auto_approve = auto_approve
        self.prompt_callback = prompt_callback

    def request_plan_approval(self, plan: Plan, diff_preview: Optional[str] = None) -> bool:
        """Present the plan to the user and request approval.

        Returns:
            True if approved, False if rejected.
        """
        if self.auto_approve:
            return True

        self._display_plan_summary(plan, diff_preview)

        prompt_text = "\nDo you approve executing this plan? [A]pprove / [R]eject: "

        while True:
            try:
                if self.prompt_callback:
                    choice = self.prompt_callback(prompt_text).strip().lower()
                else:
                    choice = input(prompt_text).strip().lower()
            except (EOFError, KeyboardInterrupt):
                return False

            if choice in ("a", "approve", "y", "yes", ""):
                return True
            elif choice in ("r", "reject", "n", "no"):
                return False
            else:
                print("Please enter 'a' to approve or 'r' to reject.")

    def _display_plan_summary(self, plan: Plan, diff_preview: Optional[str] = None) -> None:
        """Print clean summary of the proposed plan."""
        print("\n" + "=" * 60)
        print(" proposed implementation plan ".upper().center(60, "="))
        print("=" * 60)
        print(f"Task:      {plan.task}")
        print(f"Summary:   {plan.summary}")
        print(f"Rationale: {plan.rationale}\n")

        print("Proposed Steps:")
        for s in plan.steps:
            target = f" -> {s.target_file}" if s.target_file else ""
            print(f"  {s.step_number}. [{s.action.value.upper()}]{target}: {s.description}")

        if plan.verification_commands:
            print(f"\nVerification Commands: {', '.join(plan.verification_commands)}")

        if plan.potential_risks:
            print(f"Potential Risks: {', '.join(plan.potential_risks)}")

        if diff_preview:
            print("\nPreview Diff:")
            print(diff_preview)

        print("=" * 60)
