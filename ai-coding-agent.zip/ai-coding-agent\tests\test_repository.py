"""Unit tests for repository inspection and language detection."""

import os
import tempfile
from pathlib import Path
import pytest

from agent.repository import RepositoryManager
from config import Config


def test_repository_language_and_toolchain_detection():
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        # Create Python files & build files
        (root / "main.py").write_text("print('hello')", encoding="utf-8")
        (root / "pyproject.toml").write_text("[project]\nname = 'demo'", encoding="utf-8")

        # Create Rust file & Cargo manifest
        (root / "src").mkdir()
        (root / "src" / "main.rs").write_text("fn main() {}", encoding="utf-8")
        (root / "Cargo.toml").write_text("[package]\nname = 'demo_rs'", encoding="utf-8")

        # Create JS file
        (root / "index.js").write_text("console.log('hi');", encoding="utf-8")
        (root / "package.json").write_text("{}", encoding="utf-8")

        # Create README
        (root / "README.md").write_text("# Demo Repository\nDetailed documentation here.", encoding="utf-8")

        mgr = RepositoryManager()
        info = mgr.open_repo(root)

        assert "Python" in info.languages
        assert "Rust" in info.languages
        assert "JavaScript" in info.languages

        assert any("pip" in pm or "cargo" in pm or "npm" in pm for pm in info.package_managers)
        assert any("cargo test" in tr or "pytest" in tr or "npm test" in tr for tr in info.test_runners)
        assert "README.md" in info.important_files
        assert info.readme_snippet is not None
        assert "Demo Repository" in info.readme_snippet
