"""Repository manager for cloning, inspecting, and understanding codebases across multiple languages."""

import os
import re
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Union

from config import Config, default_config
from models.schemas import RepoInfo
from agent.terminal import Terminal


class RepositoryManager:
    """Manages repository cloning, structure scanning, language and toolchain detection."""

    LANGUAGE_EXTENSIONS = {
        "Python": {".py", ".pyi"},
        "JavaScript": {".js", ".jsx", ".mjs", ".cjs"},
        "TypeScript": {".ts", ".tsx"},
        "Java": {".java"},
        "Rust": {".rs"},
        "Go": {".go"},
        "C": {".c", ".h"},
        "C++": {".cpp", ".cxx", ".cc", ".hpp", ".hxx"},
        "Ruby": {".rb"},
        "PHP": {".php"},
        "C#": {".cs"},
        "HTML": {".html", ".htm"},
        "CSS": {".css", ".scss", ".sass"},
        "Markdown": {".md"},
        "Shell": {".sh", ".bash", ".ps1"},
    }

    BUILD_CONFIG_FILES = {
        "pyproject.toml": ("Python", "pip/poetry", "setuptools/poetry/flit", "pytest"),
        "setup.py": ("Python", "pip", "setuptools", "pytest/unittest"),
        "Pipfile": ("Python", "pipenv", "pipenv", "pytest"),
        "requirements.txt": ("Python", "pip", "pip", "pytest"),
        "package.json": ("JavaScript/TypeScript", "npm", "npm/vite/webpack", "npm test/jest"),
        "tsconfig.json": ("TypeScript", "npm", "tsc", "jest/vitest"),
        "Cargo.toml": ("Rust", "cargo", "cargo", "cargo test"),
        "go.mod": ("Go", "go modules", "go build", "go test"),
        "pom.xml": ("Java", "maven", "maven", "mvn test"),
        "build.gradle": ("Java", "gradle", "gradle", "gradle test"),
        "build.gradle.kts": ("Java/Kotlin", "gradle", "gradle", "gradle test"),
        "CMakeLists.txt": ("C/C++", "cmake", "cmake", "ctest"),
        "Makefile": ("C/C++", "make", "make", "make test"),
    }

    def __init__(self, config: Optional[Config] = None):
        self.config = config or default_config
        self.workspace_dir = Path(self.config.workspace_dir).resolve()
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
        self.current_repo_path: Optional[Path] = None
        self.terminal: Optional[Terminal] = None

    def open_repo(self, repo_path: Union[str, Path]) -> RepoInfo:
        """Open an existing local repository path and inspect it."""
        path = Path(repo_path).resolve()
        if not path.exists() or not path.is_dir():
            raise FileNotFoundError(f"Repository directory does not exist: {path}")

        self.current_repo_path = path
        self.terminal = Terminal(root_dir=path, timeout=self.config.command_timeout)
        return self.inspect_repository()

    def clone_repo(self, repo_url: str, target_name: Optional[str] = None) -> RepoInfo:
        """Clone a remote git repository into workspace and inspect it."""
        # Derive directory name from URL if not specified
        if not target_name:
            clean_url = repo_url.rstrip("/").removesuffix(".git")
            target_name = clean_url.split("/")[-1]
            if not target_name:
                target_name = "cloned_repo"

        target_dir = self.workspace_dir / target_name
        if target_dir.exists():
            # If already exists, simply open it
            return self.open_repo(target_dir)

        # Execute git clone
        parent_terminal = Terminal(root_dir=self.workspace_dir)
        res = parent_terminal.run(f"git clone {repo_url} {target_name}")
        if res.exit_code != 0:
            raise RuntimeError(f"Failed to clone repository from {repo_url}:\n{res.stderr or res.stdout}")

        return self.open_repo(target_dir)

    def inspect_repository(self) -> RepoInfo:
        """Thoroughly scan the active repository to detect languages, build tools, tests, and git state."""
        if not self.current_repo_path:
            raise ValueError("No repository currently loaded.")

        repo_path = self.current_repo_path
        name = repo_path.name
        is_git = (repo_path / ".git").is_dir()

        languages: Set[str] = set()
        package_managers: Set[str] = set()
        build_systems: Set[str] = set()
        test_runners: Set[str] = set()
        important_files: List[str] = []
        file_count = 0

        # Scan files ignoring standard ignored dirs
        for root, dirs, files in os.walk(repo_path):
            # Prune ignored directories in-place
            dirs[:] = [d for d in dirs if d not in self.config.ignore_dirs]

            for file_name in files:
                file_count += 1
                rel_path = os.path.relpath(os.path.join(root, file_name), repo_path)
                file_ext = os.path.splitext(file_name)[1].lower()

                # Language detection by extension
                for lang, exts in self.LANGUAGE_EXTENSIONS.items():
                    if file_ext in exts:
                        languages.add(lang)

                # Toolchain detection by build files
                if file_name in self.BUILD_CONFIG_FILES:
                    lang, pm, build, test = self.BUILD_CONFIG_FILES[file_name]
                    if "/" in lang:
                        languages.update(lang.split("/"))
                    else:
                        languages.add(lang)
                    package_managers.add(pm)
                    build_systems.add(build)
                    test_runners.add(test)
                    important_files.append(rel_path)

                # Check for test directories or files
                if "test" in file_name.lower() or "spec" in file_name.lower():
                    if file_ext in (".py",):
                        test_runners.add("pytest")
                    elif file_ext in (".js", ".ts"):
                        test_runners.add("npm test")
                    elif file_ext in (".rs",):
                        test_runners.add("cargo test")
                    elif file_ext in (".go",):
                        test_runners.add("go test")

                # Track README and LICENSE
                if file_name.lower().startswith("readme") or file_name.lower().startswith("license"):
                    if rel_path not in important_files:
                        important_files.append(rel_path)

        # Read README snippet if available
        readme_snippet = self.read_readme_snippet()

        # Git branch and status
        git_branch = None
        git_status = None
        if is_git and self.terminal:
            branch_res = self.terminal.run("git branch --show-current")
            if branch_res.exit_code == 0 and branch_res.stdout.strip():
                git_branch = branch_res.stdout.strip()

            status_res = self.terminal.run("git status --short")
            if status_res.exit_code == 0:
                git_status = status_res.stdout.strip()

        return RepoInfo(
            name=name,
            path=str(repo_path),
            is_git=is_git,
            git_branch=git_branch,
            git_status=git_status,
            languages=sorted(list(languages)),
            package_managers=sorted(list(package_managers)),
            build_systems=sorted(list(build_systems)),
            test_runners=sorted(list(test_runners)),
            important_files=sorted(important_files),
            readme_snippet=readme_snippet,
            file_count=file_count,
        )

    def read_readme_snippet(self, max_lines: int = 40) -> Optional[str]:
        """Read the initial lines of the README file for context."""
        if not self.current_repo_path:
            return None

        for name in ("README.md", "README.rst", "README.txt", "README", "readme.md"):
            readme_path = self.current_repo_path / name
            if readme_path.is_file():
                try:
                    with open(readme_path, "r", encoding="utf-8", errors="replace") as f:
                        lines = [f.readline() for _ in range(max_lines)]
                        return "".join(lines).strip()
                except Exception:
                    return None
        return None

    def get_git_diff(self) -> str:
        """Get the current uncommitted git diff of the repository."""
        if not self.terminal or not self.current_repo_path:
            return ""
        res = self.terminal.run("git diff")
        if res.exit_code == 0:
            return res.stdout
        return ""

    def get_git_log(self, limit: int = 5) -> str:
        """Get recent git commit history."""
        if not self.terminal or not self.current_repo_path:
            return ""
        res = self.terminal.run(f"git log -n {limit} --oneline")
        if res.exit_code == 0:
            return res.stdout.strip()
        return ""
