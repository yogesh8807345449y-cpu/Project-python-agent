"""Unit tests for the iterative Debugger."""

import tempfile
from pathlib import Path
import pytest

from agent.debugger import Debugger
from agent.editor import FileEditor
from agent.llm import MockLLMClient
from agent.terminal import Terminal
from agent.tester import TestRunner
from models.schemas import CommandResult, TestResult


def test_debugger_repair_loop():
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        # Create a file with a bug
        buggy_file = root / "math_utils.py"
        buggy_file.write_text("def multiply(a, b):\n    return a + b\n", encoding="utf-8")

        term = Terminal(root_dir=root)
        editor = FileEditor(repo_path=root)
        tester = TestRunner(repo_path=root, terminal=term)

        # Mock LLM returning exact repair JSON
        mock_repair_response = """
{
  "diagnosis": "Operator should be * instead of +",
  "edits": [
    {
      "file_path": "math_utils.py",
      "search_block": "return a + b",
      "replace_block": "return a * b"
    }
  ]
}
"""
        llm = MockLLMClient(custom_responses={"failing": mock_repair_response, "traceback": mock_repair_response})
        debugger = Debugger(llm=llm, editor=editor, tester=tester, max_iterations=2)

        # Initial failing test result
        failing_res = TestResult(
            runner="pytest",
            command="python -c \"import math_utils; assert math_utils.multiply(2, 3) == 6\"",
            exit_code=1,
            passed=0,
            failed=1,
            raw_output="AssertionError: 5 != 6",
            failed_tests=["test_multiply"],
            error_summary="AssertionError",
        )

        success, iterations = debugger.debug_and_fix(
            test_result=failing_res,
            test_command=failing_res.command,
            relevant_files=["math_utils.py"],
        )

        assert success is True
        assert len(iterations) == 1
        assert "math_utils.py" in iterations[0].files_modified
        assert "return a * b" in editor.read_file("math_utils.py")
