"""Safe terminal execution tool for running commands in a repository workspace."""

import os
import shlex
import subprocess
import time
from pathlib import Path
from typing import Dict, List, Optional, Union

from models.schemas import CommandResult


class Terminal:
    """Safe terminal executor with sandboxing, timeouts, and dangerous command protection."""

    # Commands or patterns that could cause irreversible system damage
    DANGEROUS_PATTERNS = [
        "rm -rf /",
        "rm -rf ~",
        "rmdir /s /q c:",
        "format c:",
        ":(){ :|:& };:",
        "dd if=/dev/zero",
        "mkfs",
        "shutdown",
        "reboot",
    ]

    def __init__(self, root_dir: Union[str, Path], timeout: int = 120):
        self.root_dir = Path(root_dir).resolve()
        self.timeout = timeout

        if not self.root_dir.exists():
            raise ValueError(f"Root directory does not exist: {self.root_dir}")

    def is_safe_command(self, command: str) -> bool:
        """Check if command contains forbidden destructive patterns."""
        normalized = command.strip().lower()
        for pattern in self.DANGEROUS_PATTERNS:
            if pattern in normalized:
                return False
        return True

    def run(
        self,
        command: str,
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[int] = None,
        env: Optional[Dict[str, str]] = None,
    ) -> CommandResult:
        """Execute a shell command safely within the repository boundaries.

        Args:
            command: Shell command string to execute.
            cwd: Working directory (must be inside root_dir; defaults to root_dir).
            timeout: Command timeout in seconds (defaults to self.timeout).
            env: Optional environment variables dictionary.

        Returns:
            CommandResult containing stdout, stderr, exit code, duration, and timed_out flag.
        """
        exec_timeout = timeout if timeout is not None else self.timeout

        # Target working directory validation
        target_cwd = Path(cwd).resolve() if cwd else self.root_dir
        try:
            target_cwd.relative_to(self.root_dir)
        except ValueError:
            # Prevent command execution outside the repository workspace
            return CommandResult(
                command=command,
                stdout="",
                stderr=f"Security Error: Working directory '{target_cwd}' is outside repository root '{self.root_dir}'.",
                exit_code=-1,
                duration=0.0,
                timed_out=False,
            )

        # Safety check
        if not self.is_safe_command(command):
            return CommandResult(
                command=command,
                stdout="",
                stderr=f"Security Error: Command blocked due to dangerous pattern.",
                exit_code=-1,
                duration=0.0,
                timed_out=False,
            )

        # Build environment with current PATH preserved and repository root in PYTHONPATH
        exec_env = os.environ.copy()
        current_pythonpath = exec_env.get("PYTHONPATH", "")
        repo_str = str(self.root_dir)
        exec_env["PYTHONPATH"] = f"{repo_str}{os.pathsep}{current_pythonpath}" if current_pythonpath else repo_str
        if env:
            exec_env.update(env)

        start_time = time.perf_counter()
        timed_out = False
        stdout_text = ""
        stderr_text = ""
        exit_code = 0

        # Run process
        try:
            # On Windows, use shell=True with powershell or cmd
            proc = subprocess.run(
                command,
                shell=True,
                cwd=str(target_cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=exec_timeout,
                env=exec_env,
                encoding="utf-8",
                errors="replace",
            )
            stdout_text = proc.stdout
            stderr_text = proc.stderr
            exit_code = proc.returncode
        except subprocess.TimeoutExpired as e:
            timed_out = True
            exit_code = -1
            stdout_text = e.stdout if isinstance(e.stdout, str) else (e.stdout.decode("utf-8", "replace") if e.stdout else "")
            stderr_text = f"Command timed out after {exec_timeout} seconds.\n" + (
                e.stderr if isinstance(e.stderr, str) else (e.stderr.decode("utf-8", "replace") if e.stderr else "")
            )
        except Exception as e:
            exit_code = -1
            stderr_text = str(e)

        duration = round(time.perf_counter() - start_time, 3)

        return CommandResult(
            command=command,
            stdout=stdout_text,
            stderr=stderr_text,
            exit_code=exit_code,
            duration=duration,
            timed_out=timed_out,
        )
