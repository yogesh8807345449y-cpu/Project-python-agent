"""End-to-end integration test verifying the full 16-step autonomous coding agent workflow."""

import json
import subprocess
import tempfile
from pathlib import Path
import pytest

from agent.agent import CodingAgent
from agent.llm import MockLLMClient
from config import Config


def test_full_autonomous_workflow_on_real_repo():
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_dir = Path(tmpdir)

        # 1. Initialize a real git repository
        subprocess.run(["git", "init"], cwd=str(repo_dir), check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subprocess.run(["git", "config", "user.name", "TestUser"], cwd=str(repo_dir), check=True)
        subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=str(repo_dir), check=True)

        # 2. Add source code with a bug
        cart_code = """
def calculate_total(prices):
    # Intentional bug: multiplying by 0.5 instead of summing directly
    return sum(prices) * 0.5
"""
        (repo_dir / "cart.py").write_text(cart_code.strip() + "\n", encoding="utf-8")

        # 3. Add test suite verifying correct behavior
        test_code = """
import pytest
from cart import calculate_total

def test_calculate_total():
    assert calculate_total([10, 20, 30]) == 60
"""
        (repo_dir / "test_cart.py").write_text(test_code.strip() + "\n", encoding="utf-8")

        # 4. Add project documentation and manifest
        (repo_dir / "README.md").write_text("# Shopping Cart Service\nHandles cart calculations.", encoding="utf-8")
        (repo_dir / "pyproject.toml").write_text("[project]\nname = 'cart-service'\nversion = '0.1.0'", encoding="utf-8")

        # Commit initial state
        subprocess.run(["git", "add", "."], cwd=str(repo_dir), check=True)
        subprocess.run(["git", "commit", "-m", "Initial commit with cart bug"], cwd=str(repo_dir), check=True)

        # 5. Set up LLM Mock with appropriate plan and code fixes
        plan_response = json.dumps({
            "summary": "Fix sum calculation in cart.py by removing incorrect multiplier.",
            "rationale": "The calculate_total function erroneously multiplies total by 0.5.",
            "steps": [
                {
                    "step_number": 1,
                    "action": "modify",
                    "target_file": "cart.py",
                    "description": "Fix calculate_total to sum prices without 0.5 multiplier.",
                    "details": "Change return sum(prices) * 0.5 to return sum(prices)"
                }
            ],
            "verification_commands": ["pytest test_cart.py"],
            "potential_risks": ["None"]
        })

        file_fix_response = json.dumps({
            "new_content": "def calculate_total(prices):\n    return sum(prices)\n"
        })

        custom_responses = {
            "plan": plan_response,
            "cart.py": file_fix_response,
        }

        mock_llm = MockLLMClient(custom_responses=custom_responses)

        cfg = Config(
            auto_approve=True,
            max_debug_iterations=2,
            command_timeout=30,
        )

        agent = CodingAgent(config=cfg, llm_client=mock_llm)

        # 6. Execute autonomous run
        task = "Fix calculate_total bug in cart.py so test_calculate_total passes."
        result = agent.run(repo_target=str(repo_dir), task=task)

        # 7. Assert complete success
        assert result.success is True, f"Agent failed: {result.final_summary}"
        assert "cart.py" in result.files_modified
        assert "+    return sum(prices)" in result.diff_summary
        assert len(result.tests_executed) >= 1
        assert result.tests_executed[-1].is_success is True

        # Check file on disk
        updated_content = (repo_dir / "cart.py").read_text(encoding="utf-8")
        assert "return sum(prices)" in updated_content
        assert "* 0.5" not in updated_content
