"""Repository search tool utilizing ripgrep or Python regex fallback."""

import fnmatch
import os
import re
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Union

from config import Config, default_config
from models.schemas import SearchMatch, SearchResult, SymbolInfo
from agent.terminal import Terminal


class RepositorySearch:
    """Fast code search engine for files, symbols, and references."""

    def __init__(self, repo_path: Union[str, Path], config: Optional[Config] = None):
        self.repo_path = Path(repo_path).resolve()
        self.config = config or default_config
        self.has_ripgrep = shutil.which("rg") is not None
        self.terminal = Terminal(root_dir=self.repo_path)

    def search(
        self,
        query: str,
        path_filter: Optional[str] = None,
        max_results: int = 50,
        case_sensitive: bool = False,
        is_regex: bool = False,
    ) -> SearchResult:
        """Search for literal text or regex patterns in repository files."""
        if self.has_ripgrep:
            return self._search_ripgrep(query, path_filter, max_results, case_sensitive, is_regex)
        return self._search_python(query, path_filter, max_results, case_sensitive, is_regex)

    def _search_ripgrep(
        self,
        query: str,
        path_filter: Optional[str] = None,
        max_results: int = 50,
        case_sensitive: bool = False,
        is_regex: bool = False,
    ) -> SearchResult:
        """Execute search using ripgrep CLI."""
        cmd = ["rg", "--line-number", "--no-heading", "--color=never"]
        if not case_sensitive:
            cmd.append("-i")
        if not is_regex:
            cmd.append("-F")
        for ig in self.config.ignore_dirs:
            cmd.extend(["-g", f"!{ig}"])
        if path_filter:
            cmd.extend(["-g", path_filter])

        cmd.extend(["-e", f'"{query}"', "."])
        command_str = " ".join(cmd)

        res = self.terminal.run(command_str)
        matches: List[SearchMatch] = []
        truncated = False

        if res.exit_code == 0 and res.stdout:
            for line in res.stdout.splitlines():
                if len(matches) >= max_results:
                    truncated = True
                    break
                parts = line.split(":", 2)
                if len(parts) >= 3:
                    file_p = parts[0].strip()
                    try:
                        line_num = int(parts[1].strip())
                        content = parts[2].strip()
                        matches.append(SearchMatch(file_path=file_p, line_number=line_num, line_content=content))
                    except ValueError:
                        continue

        return SearchResult(
            query=query,
            matches=matches,
            total_matches=len(matches),
            truncated=truncated,
        )

    def _search_python(
        self,
        query: str,
        path_filter: Optional[str] = None,
        max_results: int = 50,
        case_sensitive: bool = False,
        is_regex: bool = False,
    ) -> SearchResult:
        """Fallback Python search traversing files."""
        flags = 0 if case_sensitive else re.IGNORECASE
        if is_regex:
            try:
                pattern = re.compile(query, flags)
            except re.error:
                pattern = re.compile(re.escape(query), flags)
        else:
            pattern = re.compile(re.escape(query), flags)

        matches: List[SearchMatch] = []
        truncated = False

        for root, dirs, files in os.walk(self.repo_path):
            dirs[:] = [d for d in dirs if d not in self.config.ignore_dirs]

            for file_name in files:
                rel_path = os.path.relpath(os.path.join(root, file_name), self.repo_path)
                if path_filter and not fnmatch.fnmatch(rel_path, path_filter):
                    continue

                full_path = os.path.join(root, file_name)
                # Skip binary / large files
                try:
                    with open(full_path, "r", encoding="utf-8", errors="replace") as f:
                        for line_idx, line in enumerate(f, 1):
                            if pattern.search(line):
                                matches.append(
                                    SearchMatch(
                                        file_path=rel_path.replace("\\", "/"),
                                        line_number=line_idx,
                                        line_content=line.strip(),
                                    )
                                )
                                if len(matches) >= max_results:
                                    truncated = True
                                    return SearchResult(
                                        query=query,
                                        matches=matches,
                                        total_matches=len(matches),
                                        truncated=truncated,
                                    )
                except Exception:
                    continue

        return SearchResult(
            query=query,
            matches=matches,
            total_matches=len(matches),
            truncated=truncated,
        )

    def search_file(self, pattern: str) -> List[str]:
        """Find files matching a glob pattern (e.g. '*test*.py', 'login.ts')."""
        matching_files: List[str] = []
        for root, dirs, files in os.walk(self.repo_path):
            dirs[:] = [d for d in dirs if d not in self.config.ignore_dirs]

            for file_name in files:
                rel_path = os.path.relpath(os.path.join(root, file_name), self.repo_path).replace("\\", "/")
                if fnmatch.fnmatch(file_name, pattern) or fnmatch.fnmatch(rel_path, pattern):
                    matching_files.append(rel_path)

        return sorted(matching_files)

    def search_symbol(self, symbol: str) -> List[SymbolInfo]:
        """Search for class, function, method, struct, or variable definitions."""
        # Symbol definition regexes across languages
        patterns = [
            # Python def / class
            (r"^\s*def\s+(" + re.escape(symbol) + r")\s*\(", "function"),
            (r"^\s*class\s+(" + re.escape(symbol) + r")(?:\(|:|\s)", "class"),
            # JS/TS function, class, const/let
            (r"^\s*(?:export\s+)?(?:async\s+)?function\s+(" + re.escape(symbol) + r")\s*\(", "function"),
            (r"^\s*(?:export\s+)?class\s+(" + re.escape(symbol) + r")\b", "class"),
            (r"^\s*(?:const|let|var)\s+(" + re.escape(symbol) + r")\s*=", "variable"),
            # Rust fn / struct / enum / trait
            (r"^\s*(?:pub\s+)?fn\s+(" + re.escape(symbol) + r")\b", "function"),
            (r"^\s*(?:pub\s+)?(?:struct|enum|trait)\s+(" + re.escape(symbol) + r")\b", "struct/type"),
            # Go func / type
            (r"^\s*func\s+(?:\([^)]+\)\s+)?(" + re.escape(symbol) + r")\s*\(", "function"),
            (r"^\s*type\s+(" + re.escape(symbol) + r")\s+(?:struct|interface)", "struct/interface"),
            # Java / C++
            (r"^\s*(?:public|private|protected|static|\s)*[\w<>\[\]]+\s+(" + re.escape(symbol) + r")\s*\(", "method"),
        ]

        compiled = [(re.compile(p), kind) for p, kind in patterns]
        symbols: List[SymbolInfo] = []

        for root, dirs, files in os.walk(self.repo_path):
            dirs[:] = [d for d in dirs if d not in self.config.ignore_dirs]

            for file_name in files:
                rel_path = os.path.relpath(os.path.join(root, file_name), self.repo_path).replace("\\", "/")
                full_path = os.path.join(root, file_name)

                try:
                    with open(full_path, "r", encoding="utf-8", errors="replace") as f:
                        for line_idx, line in enumerate(f, 1):
                            for regex, kind in compiled:
                                match = regex.search(line)
                                if match:
                                    symbols.append(
                                        SymbolInfo(
                                            name=match.group(1),
                                            kind=kind,
                                            file_path=rel_path,
                                            line_number=line_idx,
                                            signature=line.strip(),
                                        )
                                    )
                                    break
                except Exception:
                    continue

        return symbols

    def find_references(self, symbol: str, max_results: int = 50) -> SearchResult:
        """Find occurrences and usages of a symbol across the repository."""
        word_boundary_query = rf"\b{re.escape(symbol)}\b"
        return self.search(word_boundary_query, max_results=max_results, is_regex=True)
