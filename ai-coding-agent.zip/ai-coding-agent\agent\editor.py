"""Safe file editor tool with path sandboxing, atomic writes, diff generation, and undo support."""

import difflib
import os
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Union

from models.schemas import FileChange


class FileEditor:
    """Safely inspects, modifies, and patches files within the repository boundary."""

    def __init__(self, repo_path: Union[str, Path]):
        self.repo_path = Path(repo_path).resolve()
        if not self.repo_path.exists():
            raise ValueError(f"Repository path does not exist: {self.repo_path}")

        self.backups: Dict[str, Optional[str]] = {}  # rel_path -> original content (None if was new file)
        self.modified_files: Set[str] = set()

    def _resolve_safe_path(self, file_path: Union[str, Path]) -> Tuple[Path, str]:
        """Validate and resolve file path to ensure it remains strictly inside repository root."""
        p = Path(file_path)
        if not p.is_absolute():
            resolved = (self.repo_path / p).resolve()
        else:
            resolved = p.resolve()

        try:
            rel = resolved.relative_to(self.repo_path).as_posix()
        except ValueError:
            raise PermissionError(f"Access denied: '{file_path}' resolves outside repository root '{self.repo_path}'.")

        return resolved, rel

    def read_file(self, file_path: Union[str, Path]) -> str:
        """Read full content of a file within the repository."""
        target, _ = self._resolve_safe_path(file_path)
        if not target.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        if not target.is_file():
            raise IsADirectoryError(f"Path is a directory, not a file: {file_path}")

        with open(target, "r", encoding="utf-8-sig", errors="replace") as f:
            return f.read()

    def view_lines(self, file_path: Union[str, Path], start: int = 1, end: Optional[int] = None) -> str:
        """Read a specific line range (1-indexed, inclusive) from a file."""
        content = self.read_file(file_path)
        lines = content.splitlines(keepends=True)
        total = len(lines)

        start_idx = max(1, start) - 1
        end_idx = total if end is None else min(total, end)

        selected = lines[start_idx:end_idx]
        return "".join(selected)

    def write_file(self, file_path: Union[str, Path], content: str) -> FileChange:
        """Write full content to a file (creates parent directories if needed)."""
        target, rel = self._resolve_safe_path(file_path)
        is_new = not target.exists()

        old_content: Optional[str] = None
        if not is_new:
            old_content = self.read_file(target)
            if rel not in self.backups:
                self.backups[rel] = old_content
        else:
            if rel not in self.backups:
                self.backups[rel] = None

        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "w", encoding="utf-8") as f:
            f.write(content)

        self.modified_files.add(rel)
        diff = self._generate_diff(rel, old_content or "", content)

        return FileChange(
            file_path=rel,
            old_content=old_content,
            new_content=content,
            diff=diff,
            is_new_file=is_new,
            is_deleted=False,
        )

    def replace_content(
        self,
        file_path: Union[str, Path],
        target_content: str,
        replacement_content: str,
    ) -> FileChange:
        """Replace a unique block of text within a file."""
        target, rel = self._resolve_safe_path(file_path)
        original = self.read_file(target)

        occurrences = original.count(target_content)
        if occurrences == 0:
            raise ValueError(f"Target content not found in '{rel}'.")
        if occurrences > 1:
            raise ValueError(
                f"Target content matches {occurrences} times in '{rel}'. Please provide a more specific unique context."
            )

        new_content = original.replace(target_content, replacement_content, 1)
        return self.write_file(target, new_content)

    def delete_file(self, file_path: Union[str, Path]) -> bool:
        """Delete a file within the repository."""
        target, rel = self._resolve_safe_path(file_path)
        if not target.exists():
            return False

        if rel not in self.backups:
            self.backups[rel] = self.read_file(target)

        target.unlink()
        self.modified_files.add(rel)
        return True

    def _generate_diff(self, filename: str, old_str: str, new_str: str) -> str:
        """Generate unified diff between two text strings."""
        old_lines = old_str.splitlines(keepends=True)
        new_lines = new_str.splitlines(keepends=True)
        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}",
        )
        return "".join(diff)

    def get_diff(self, file_path: Optional[Union[str, Path]] = None) -> str:
        """Get unified diff for a specific file or all modified files."""
        if file_path:
            _, rel = self._resolve_safe_path(file_path)
            orig = self.backups.get(rel, "") or ""
            current = self.read_file(rel) if (self.repo_path / rel).exists() else ""
            return self._generate_diff(rel, orig, current)

        all_diffs = []
        for rel in sorted(list(self.modified_files)):
            orig = self.backups.get(rel)
            target = self.repo_path / rel
            current = self.read_file(rel) if target.exists() else ""
            diff = self._generate_diff(rel, orig or "", current)
            if diff:
                all_diffs.append(diff)

        return "\n".join(all_diffs)

    def rollback(self) -> List[str]:
        """Revert all changes made during this editing session."""
        reverted = []
        for rel, original in self.backups.items():
            target = self.repo_path / rel
            if original is None:
                if target.exists():
                    target.unlink()
                    reverted.append(rel)
            else:
                with open(target, "w", encoding="utf-8") as f:
                    f.write(original)
                reverted.append(rel)

        self.backups.clear()
        self.modified_files.clear()
        return reverted
