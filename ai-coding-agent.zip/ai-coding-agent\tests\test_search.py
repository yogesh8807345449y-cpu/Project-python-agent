"""Unit tests for repository search functionality."""

import tempfile
from pathlib import Path
import pytest

from agent.search import RepositorySearch


def test_search_and_symbols():
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)
        # Create sample files
        (root / "auth.py").write_text(
            "def authenticate_user(username, password):\n    return True\n\nclass SessionManager:\n    pass\n",
            encoding="utf-8",
        )
        (root / "cart.py").write_text(
            "def calculate_total(items):\n    return sum(items)\n",
            encoding="utf-8",
        )

        searcher = RepositorySearch(repo_path=root)

        # 1. Text Search
        res = searcher.search("authenticate_user")
        assert res.total_matches == 1
        assert "auth.py" in res.matches[0].file_path
        assert res.matches[0].line_number == 1

        # 2. File Search
        files = searcher.search_file("*.py")
        assert len(files) == 2
        assert "auth.py" in files
        assert "cart.py" in files

        # 3. Symbol Search
        symbols = searcher.search_symbol("authenticate_user")
        assert len(symbols) == 1
        assert symbols[0].kind == "function"
        assert symbols[0].file_path == "auth.py"

        class_symbols = searcher.search_symbol("SessionManager")
        assert len(class_symbols) == 1
        assert class_symbols[0].kind == "class"

        # 4. References Search
        refs = searcher.find_references("calculate_total")
        assert refs.total_matches >= 1
